<?php if(empty($phone)): ?>
    <?php return redirect()->route('not_found'); ?>
<?php endif; ?>




<?php $__env->startSection('title', $phone->title); ?>
<?php $__env->startSection('style'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="checkout-wrapper section col-12 pt-4 pb-4 ">
   <div class="container">
      <div class="row shadow-lg py-3 rounded-3 justify-content-center">
         <div class="col-md-6">
            <div class="main-img border text-center col-12">
               <img width="100%"
                  src="<?php echo e($phone->main_image); ?>"
                  id="current" alt="#">
            </div>
            <?php if(!empty($phone->additional_images)): ?>
            <div class="images row border py-3 mt-4">

               <?php
               $additionalImages = json_decode($phone->additional_images, true);
           ?>

           <?php $__currentLoopData = $additionalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-3 text-center mb-3" role="button">
                   <img width="95%" height="100%" src="<?php echo e($image); ?>" class="img select-img" alt="#">
               </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
         <?php endif; ?>
         </div>
         <div class="col-md-6">
            <div class="product-info">
               <h1 class="title"><?php echo e($phone->title); ?></h1>
               <div class="d-flex justify-content-between">
                   <p class="category"> Posted by:<a href="<?php echo e(route('profile.show',$id=$phone->user)); ?>"><?php echo e($phone->user->first_name." ".$phone->user->last_name); ?></a></p>
                   <p class="category"> Posted: <spna class="text-muted"><?php echo e(dateDiff($phone->created_at)); ?></span></p>
                   </div>
               <h3 class="price">Price : <span ><?php echo e($phone->formatted_price); ?>

            </span></h3>
               

               <table class="table table-striped table-hover">
                <tbody>
                  <tr>
                    <th scope="row">Brand</th>
                    <td><?php echo $phone->brand ? $phone->get_brand->name : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Model</th>
                    <td><?php echo $phone->model ? $phone->model : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Color</th>
                    <td><?php echo $phone->color ? $phone->color : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Storage</th>
                    <td><?php echo $phone->storage_capacity ? $phone->storage_capacity. "GB" : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">RAM</th>
                    <td><?php echo $phone->ram ? $phone->ram." GB" : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <tr>
                    <th scope="row">Warranty</th>
                    <td>
                        <?php if($phone->warranty_status): ?>

                        <span class="<?php echo e(($phone->warranty_status != 'active') ? 'text-danger' : 'text-success'); ?>"><?php echo e($phone->warranty_status); ?></span>
                        <?php if($phone->warranty_status == "active"): ?>
                                (expiring on <?php echo e($phone->expiration_date); ?>)
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-muted font-italic">Not Provided</span>
                        <?php endif; ?>
                    </td>
                                      </tr>
                  <tr>
                    <th scope="row">Overall Condition</th>
                    <td><?php echo $phone->condition ? $phone->condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                  </tr>
                  <!-- Add more issues as needed -->
                </tbody>
              </table>

            </div>

            <div class="bottom-content">
               <div class="row align-items-end">
                  <div class="col-md-4 text-center">
                    <?php if($phone->status!="Available"): ?>
                    <button class="btn btn-outline-danger " disabled style="width: 100%;"><i class="bi bi-slash-circle"></i> SOLD</button>
                    <?php else: ?>

                     <button class="btn btn-outline-primary addToCart" data-phone-id="<?php echo e($phone->id); ?>" style="width: 100%;"><i class="bi bi-cart3"></i> Add to Cart</button>
                    <?php endif; ?>
                    </div>
                  <div class="col-md-4 text-center">
                     <button class="btn btn-outline-khas-primary"><i class="bi bi-arrow-left-right"></i> Add to Compare</button>
                  </div>
                  <div class="col-md-4 text-center">
                     <button class="btn btn-outline-khas-primary add-to-favorites" data-phone-id="<?php echo e($phone->id); ?>"><i class="bi bi-suit-heart"></i> Add to Wishlist</button>
                  </div>
                  <?php if($phone->status==="Available"): ?>
                  <div class="col-12 text-center my-4">
                     <button class="btn col-12 btn-khas-primary checkoutBtn" data-phone-id="<?php echo e($phone->id); ?>"><i class="bi bi-bag-fill"></i> Buy Now</button>

                  </div>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </div>
      <?php if($phone->description): ?>
      <h3 class="mb-3 mt-4 w-100 text-center">Description</h3>
<p><?php echo e($phone->description); ?></p>
      <?php endif; ?>
      <table style="table-layout: fixed" class="table table-bordered  table-hover">
        <tbody>
            <tr>
                <th scope="row">Status</th>
                <td><?php echo $phone->status ? $phone->status : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
            <tr>
                <th scope="row">Original Box</th>
                <td><?php echo $phone->original_packaging ? $phone->original_packaging : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
            <tr>
                <th scope="row">Condition</th>
                <td><?php echo $phone->condition ? $phone->condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
            <tr>
                <th scope="row">Purchase Date</th>
                <td><?php echo $phone->purchase_date ? $phone->purchase_date : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
           <tr>
    <th scope="row">Purchase Proof</th>
    <td>
        <?php if($phone->purchase_proof): ?>
            <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#purchaseProofModal">
                View
            </button>

            <!-- Modal -->
            <div class="modal fade" id="purchaseProofModal" tabindex="-1" aria-labelledby="purchaseProofModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="purchaseProofModalLabel">Purchase Proof</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="<?php echo e($phone->purchase_proof); ?>" alt="Purchase Proof" class="img-fluid">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <span class="text-muted font-italic">Not Provided</span>
        <?php endif; ?>
    </td>
</tr>

            <tr>
                <th scope="row">Warranty Status</th>
                <td>
                    <?php if($phone->warranty_status): ?>
                        <span class="<?php echo e(($phone->warranty_status != 'active') ? 'text-danger' : 'text-success'); ?>"><?php echo e($phone->warranty_status); ?></span>
                        <?php if($phone->warranty_status == "active"): ?>
                            (expiring on <?php echo e($phone->expiration_date); ?>)
                        <?php endif; ?>
                        <?php else: ?>
                        <span class="text-muted font-italic">Not Provided</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th scope="row">Accessories</th>
                <td><?php echo $phone->accessories ? implode(', ', json_decode($phone->accessories)) : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
            <tr>
                <th scope="row">Reason for Selling</th>
                <td><?php echo $phone->reason_for_selling ? $phone->reason_for_selling : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
            </tr>
        </tbody>
        /</table>



        <ul class="nav nav-tabs" id="myTabs" role="tablist">
            <li class="nav-item col" role="presentation">
                <a class="nav-link active" id="issues-tab" data-bs-toggle="tab" href="#issues" role="tab" aria-controls="issues" aria-selected="true">Issues/Damages</a>
            </li>
            <li class="nav-item col" role="presentation">
                <a class="nav-link" id="conditions-tab" data-bs-toggle="tab" href="#conditions" role="tab" aria-controls="conditions" aria-selected="false">Conditions</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabsContent">
            <div class="tab-pane fade show active" id="issues" role="tabpanel" aria-labelledby="issues-tab">
                <!-- issues content goes here -->
                <table class="table table-striped table-hover my-3">
                    <tbody>



                        <tr>
                            <th scope="row">Battery Health</th>
                            <td><?php echo $phone->battery_health ? $phone->battery_health . '%' : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>


                        <tr>
                            <th scope="row">Front Screen Condition</th>
                            <td><?php echo $phone->front_screen_condition ? $phone->front_screen_condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Back Cover Condition</th>
                            <td><?php echo $phone->back_cover_condition ? $phone->back_cover_condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Frame Edges Condition</th>
                            <td><?php echo $phone->frame_edges_condition ? $phone->frame_edges_condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Buttons Condition</th>
                            <td><?php echo $phone->buttons_condition ? $phone->buttons_condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Ports Condition</th>
                            <td><?php echo $phone->ports_condition ? $phone->ports_condition : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Touchscreen Functionality</th>
                            <td><?php echo $phone->touchscreen_functionality ? $phone->touchscreen_functionality : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>




                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="conditions" role="tabpanel" aria-labelledby="conditions-tab">
                <!-- Conditions content goes here -->
                <table class="table table-striped table-hover my-3">
                    <tbody>

                        <tr>
                            <th scope="row">Screen Damage</th>
                            <td><?php echo $phone->screen_damage ? $phone->screen_damage : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Water Damage</th>
                            <td><?php echo $phone->water_damage ? $phone->water_damage : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Battery Issues</th>
                            <td><?php echo $phone->battery_issues ? $phone->battery_issues : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Camera Issues</th>
                            <td><?php echo $phone->camera_issues ? $phone->camera_issues : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Audio Issues</th>
                            <td><?php echo $phone->audio_issues ? $phone->audio_issues : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Connectivity Issues</th>
                            <td><?php echo $phone->connectivity_issues ? $phone->connectivity_issues : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Sensor Issues</th>
                            <td><?php echo $phone->sensor_issues ? $phone->sensor_issues : '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Software Issues</th>
                            <td><?php echo $phone->software_issues ? $phone->software_issues: '<span class="text-muted font-italic">Not Provided</span>'; ?></td>
                        </tr>





                    </tbody>
                </table>
            </div>

            <div class="container mt-5">
                <h3>Related Phones</h3>
                <div class="row">
                    <!-- Replace the static content with dynamic content fetched from your database -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <img src="https://via.placeholder.com/150" class="card-img-top" alt="Phone Image">
                            <div class="card-body">
                                <h5 class="card-title">Phone 1</h5>
                                <p class="card-text">Phone 1 description...</p>
                                <a href="#" class="btn btn-primary">View Details</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <img src="https://via.placeholder.com/150" class="card-img-top" alt="Phone Image">
                            <div class="card-body">
                                <h5 class="card-title">Phone 2</h5>
                                <p class="card-text">Phone 2 description...</p>
                                <a href="#" class="btn btn-primary">View Details</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <img src="https://via.placeholder.com/150" class="card-img-top" alt="Phone Image">
                            <div class="card-body">
                                <h5 class="card-title">Phone 3</h5>
                                <p class="card-text">Phone 3 description...</p>
                                <a href="#" class="btn btn-primary">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


   </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
    // Image selection script
    $('.select-img').click(function () {
        var selected = $(this).attr("src");
        $('#current').attr("src", selected);
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserViews/Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Product/product-details.blade.php ENDPATH**/ ?>