<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    

    <title><?php echo $__env->yieldContent('title'); ?></title>

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v6.0.0-beta3/css/all.css">
<link rel="stylesheet" href="<?php echo e(asset('css/extend-bootstrap.min.css')); ?>">

 <!-- Icon File -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
 <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
<!-- Include Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


<!-- Toastr CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<link rel="stylesheet" href="<?php echo e(asset('css/khas.css')); ?>">
<style>
.select2-container--default .select2-selection--single {
    height: 38px;
    border: 1px solid #ced4da;
    border-radius: 4px;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 36px;
    padding-left: 12px;
    font-size: 1rem;
}

.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 36px;
    position: absolute;
    top: 1px;
    right: 1px;
    width: 20px;
}

.select2-container .select2-selection--single .select2-selection__arrow b {
    border-color: #495057 transparent transparent transparent;
}

</style>

<?php echo $__env->yieldContent('style'); ?>
</head>
<body>

    <?php echo $__env->make('UserViews/Layout/Includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="container-fluid ">

    <?php echo $__env->yieldContent('content'); ?>


        </main>
    <?php echo $__env->make('UserViews/Layout/Includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    


    !-- Fav Modal -->
    <div class="modal fade" id="favModal" tabindex="-1" aria-labelledby="favModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="favModalLabel">Favourite Phones</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <?php if(auth()->check()): ?>
              <?php $__currentLoopData = Auth::user()->favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<table class="table table-striped">
<thead>
  <tr>
    <th>
      Product
    </th>
    <th>
      Added on
    </th>
    <th>
      Action
    </th>
  </tr>
</thead>
<tbody>
<tr>
 <td>
<div class="d-flex align-items-center">

  <img src="<?php echo e($fav->phone->main_image); ?>" width="50px"/>
<p class="mx-2 my-auto"><?php echo e($fav->phone->title); ?></p>
<div>
 </td>
 <td>

  <?php echo e(dateDiff($fav->created_at)); ?>

 </td>
 <td>
  <a href="<?php echo e(route('phones.show',$id=$fav->phone_id)); ?>"class="btn btn-sm btn-success text-light"><i class="bi bi-eye"></i></a>
  <a class="btn btn-sm btn-danger remove-fav text-light" data-fav-id="<?php echo e($fav->id); ?>"><i class="bi bi-trash3-fill"></i></a>
 </td>
</tr>
</tbody>
</table>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>



    <div class="modal" id="exampleModal" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-body">
              <p>Are you Sure You Wants To Delete?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-danger confirm-deleted">Yes</button>
            </div>
          </div>
        </div>
      </div>

</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<!-- Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<!-- Include Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script src="<?php echo e(asset('js/khas.js')); ?>"></script>
<script>
  $(document).ready(function() {
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
});



  $(document).ready(function() {
        $('select').select2();
    });
    </script>
     <?php echo $__env->yieldContent('script'); ?>
    </body>
    <?php if(session('success')): ?>
    <script>
      toastr.success('<?php echo e(session('success')); ?>');
    </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <script>
      toastr.error('<?php echo e(session('error')); ?>');
    </script>
    <?php endif; ?>
    <?php if(session('info')): ?>
    <script>
      toastr.info('<?php echo e(session('info')); ?>');
    </script>
    <?php endif; ?>
    <?php if(session('warning')): ?>
    <script>
      toastr.warning('<?php echo e(session('warning')); ?>');
    </script>
    <?php endif; ?>

</html>
<?php /**PATH C:\xampp\htdocs\khas\resources\views/UserViews/Layout/layout.blade.php ENDPATH**/ ?>