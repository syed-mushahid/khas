@extends('Layout.layout')
@section('title','Products')
@section('style')
<style>

</style>

@endsection

@section('content')
  
    
  <main id="main" class="main">


    <section class="section dashboard">
      <div class="row">
        <div class="col-12">
          <div class="row">


{{-- Content Code Here --}}



        
      </div>
    </section>

  </main>
@endsection

@section('script')

<script>

</script>
@endsection