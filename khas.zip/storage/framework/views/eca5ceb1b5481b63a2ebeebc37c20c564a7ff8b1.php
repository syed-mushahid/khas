
<?php $__env->startSection('title','Pending Orders'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="checkout-wrapper section col-12 pt-4 pb-4 ">
   <div class="container">
      <div class="row justify-content-center ">
        <?php echo $__env->make('RiderViews/Profile/Components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="my-4 col-md-9">


<table class="table table-striped shadow-lg rounded-4 p-4 bg-white">
    <tr>
        <th>Order ID</th>
        <th>Product</th>
        <th>Pickup Date/Time</th>
        <th>Delivery Date/Time</th>
        <th>Action</th>
    </tr>
    <tr>
        <td>1221</td>
        <td>I phone 6</td>
        <td>2-Feb-2023, 9:00 PM</td>
        <td>2-Feb-2023, 1:00 PM</td>
        <td><button class="btn btn-sm btn-success me-2">Accept</button><button class="btn btn-sm btn-danger">Reject</button></td>
    </tr>
    <tr>
        <td>1221</td>
        <td>Samsung Glaxy S10</td>
        <td>2-Feb-2023, 9:00 PM</td>
        <td>2-Feb-2023, 12:00 PM</td>
        <td><button class="btn btn-sm btn-success me-2">Accept</button><button class="btn btn-sm btn-danger">Reject</button></td>
    </tr>
</table>
</div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserViews/Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\khas\resources\views/RiderViews/Orders/new-orders.blade.php ENDPATH**/ ?>